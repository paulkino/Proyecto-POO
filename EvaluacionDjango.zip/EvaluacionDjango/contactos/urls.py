from django.urls import path
from . import views # Aquí sí importamos las vistas de la app

urlpatterns = [
    path('', views.lista_contactos, name='lista_contactos'),
    path('nuevo/', views.agregar_contacto, name='crear_contacto'),
    path('favorito/<int:contacto_id>/', views.toggle_favorito, name='toggle_favorito'),
]