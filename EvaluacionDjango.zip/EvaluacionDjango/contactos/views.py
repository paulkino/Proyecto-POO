from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from .models import Contacto
from .forms import ContactoForm

# 1. Vista para listar contactos (La que te da el error)
def lista_contactos(request):
    # Ordenamos: favoritos primero, luego por nombre
    contactos = Contacto.objects.all().order_by('-favorito', 'nombre')
    return render(request, 'contactos/lista.html', {'contactos': contactos})

# 2. Vista para agregar contactos
def agregar_contacto(request):
    if request.method == 'POST':
        form = ContactoForm(request.POST, request.FILES) # IMPORTANTE: request.FILES para la foto
        if form.is_valid():
            form.save()
            return redirect('lista_contactos')
    else:
        form = ContactoForm()
    return render(request, 'contactos/formulario.html', {'form': form})

# 3. Vista para el botón de favorito (AJAX)
def toggle_favorito(request, contacto_id):
    contacto = get_object_or_404(Contacto, id=contacto_id)
    contacto.favorito = not contacto.favorito
    contacto.save()
    return JsonResponse({'favorito': contacto.favorito})# contactos/views.py

from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import Contacto

# Verifica que el nombre sea exactamente este:
def toggle_favorito(request, contacto_id):
    if request.method == "POST":
        contacto = get_object_or_404(Contacto, id=contacto_id)
        contacto.favorito = not contacto.favorito
        contacto.save()
        return JsonResponse({'status': 'ok', 'favorito': contacto.favorito})
    return JsonResponse({'status': 'error'}, status=400)