📔 Sistema de Gestión de Contactos - Evaluación Final POO

Este proyecto es una aplicación web construida con Django 4.2 LTS, diseñada para gestionar una agenda de contactos con funcionalidades avanzadas de base de datos, lógica de negocio personalizada e interactividad moderna.

🎯 Objetivos Cumplidos
Modelo de Datos: Implementación de campos BooleanField para favoritos y ImageField para fotografía.

Lógica de Negocio: Ordenamiento prioritario (favoritos primero, luego alfabético).

Multimedia: Gestión completa de subida y visualización de imágenes.

Experiencia de Usuario: Uso de AJAX (Fetch API) para actualizar favoritos en tiempo real sin recargar la página.

Estética: Interfaz diseñada con CSS Grid y diseño responsivo.

🛠️ Requisitos previos
macOS con Python 3.10 o superior.

Entorno virtual activo (venv).

Librería Pillow instalada (para el manejo de imágenes).

🚀 Guía de Instalación y Ejecución
Sigue estos pasos en tu terminal para desplegar el proyecto localmente:

1. Clonar y Preparar el Entorno
Bash
# Entrar a la carpeta del proyecto
cd EvaluacionDjango

# Crear y activar el entorno virtual
python3 -m venv venv
source venv/bin/activate

# Instalar dependencias necesarias
pip install django==4.2 pillow
2. Configuración de Base de Datos y Estáticos
Es fundamental aplicar las migraciones y recolectar los archivos estáticos para que el panel de administración y la interfaz se vean correctamente:

Bash
# Aplicar migraciones
python3 manage.py makemigrations
python3 manage.py migrate

# Recolectar archivos estáticos (Soluciona errores 404 de CSS)
python3 manage.py collectstatic --noinput
3. Ejecutar el Servidor
Bash
python3 manage.py runserver
Accede a la aplicación en: http://127.0.0.1:8000/

📂 Estructura del Proyecto
/contactos: Aplicación con la lógica del CRUD, modelos y vistas.

/media: Carpeta donde se almacenan las fotografías de los contactos.

/static: Archivos CSS y scripts de JavaScript para la lógica de favoritos.

/agenda_pro: Configuración global del proyecto y rutas principales.

💡 Notas
Para probar el Ordenamiento Prioritario, marque un contacto con la estrella ⭐; verá cómo se posiciona automáticamente al inicio tras recargar o crear uno nuevo.

El formulario de creación incluye el atributo enctype="multipart/form-data", garantizando la integridad de los archivos multimedia subidos.